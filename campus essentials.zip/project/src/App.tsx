import React, { useState } from 'react';
import { 
  ChevronDown, 
  ChevronUp, 
  Clock, 
  Store, 
  User, 
  Bus, 
  Car, 
  Phone,
  Utensils,
  MapPin,
  AlertTriangle,
  Users
} from 'lucide-react';

interface CollapsibleSectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const CollapsibleSection: React.FC<CollapsibleSectionProps> = ({ 
  title, 
  icon, 
  children, 
  defaultOpen = false 
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-white rounded-xl shadow-lg mb-6 overflow-hidden transition-all duration-300 hover:shadow-xl">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-6 flex items-center justify-between text-left bg-gradient-to-r from-blue-50 to-orange-50 hover:from-blue-100 hover:to-orange-100 transition-colors duration-200"
      >
        <div className="flex items-center space-x-3">
          <div className="text-blue-600">
            {icon}
          </div>
          <h2 className="text-xl font-bold text-gray-800">{title}</h2>
        </div>
        <div className="text-blue-600">
          {isOpen ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
        </div>
      </button>
      
      {isOpen && (
        <div className="p-6 pt-0 animate-fadeIn">
          {children}
        </div>
      )}
    </div>
  );
};

const ContactCard: React.FC<{ name: string; phone: string; label?: string }> = ({ 
  name, 
  phone, 
  label 
}) => (
  <div className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors duration-200">
    <div className="flex justify-between items-center">
      <div>
        <h4 className="font-semibold text-gray-800">{name}</h4>
        {label && <p className="text-sm text-gray-600">{label}</p>}
      </div>
      <a 
        href={`tel:${phone}`} 
        className="bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center space-x-1"
      >
        <Phone size={16} />
        <span className="text-sm font-medium">{phone}</span>
      </a>
    </div>
  </div>
);

const AutoDriverGrid: React.FC = () => {
  const drivers = [
    '96035 11629', '98481 65044', '99484 83171', '90000 92037',
    '63025 36271', '98664 72092', '99599 78917', '96768 07459',
    '99484 83171', '77023 86068', '95533 75890', '90106 97472',
    '97055 52391', '98481 65044', '95248 76740', '98664 72092',
    '90107 90411', '99484 83171', '90000 92037', '98481 28649',
    '91775 20097', '80740 12874', '86869 37544'
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
      {drivers.map((phone, index) => (
        <a
          key={index}
          href={`tel:${phone}`}
          className="bg-gradient-to-r from-orange-50 to-red-50 p-3 rounded-lg text-center hover:from-orange-100 hover:to-red-100 transition-all duration-200 border border-orange-200 hover:border-orange-300"
        >
          <div className="text-sm font-medium text-gray-700 mb-1">
            {index + 1}
          </div>
          <div className="text-sm font-mono text-orange-700">
            {phone}
          </div>
        </a>
      ))}
    </div>
  );
};

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-orange-500 text-white py-8 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Campus Essentials</h1>
          <p className="text-blue-100 text-lg">BITS Pilani, Hyderabad Campus</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        
        {/* Mess Timings & Menu */}
        <CollapsibleSection 
          title="Mess Timings & Menu" 
          icon={<Utensils size={24} />}
          defaultOpen={true}
        >
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-semibold text-green-800 mb-3 flex items-center">
                  <Clock size={16} className="mr-2" />
                  Mess Timings
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="font-medium">Breakfast:</span>
                    <span>7:30 AM - 9:30 AM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Lunch:</span>
                    <span>12:00 PM - 2:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Snacks:</span>
                    <span>5:00 PM - 6:30 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Dinner:</span>
                    <span>8:00 PM - 10:00 PM</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-blue-800 mb-3">Weekly Menu</h3>
                <p className="text-blue-700 text-sm mb-3">Menu updated weekly by mess committee</p>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                  Download Current Menu
                </button>
              </div>
            </div>
          </div>
        </CollapsibleSection>

        {/* Campus Outlets */}
        <CollapsibleSection 
          title="Campus Outlet Details" 
          icon={<Store size={24} />}
        >
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 text-left font-semibold">Outlet Name</th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">Timings</th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">Specialties</th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">Contact</th>
                </tr>
              </thead>
              <tbody>
                <tr className="hover:bg-gray-50">
                  <td className="border border-gray-300 p-3 font-medium">Cafeteria</td>
                  <td className="border border-gray-300 p-3">8:00 AM - 10:00 PM</td>
                  <td className="border border-gray-300 p-3">Snacks, Beverages, Quick Bites</td>
                  <td className="border border-gray-300 p-3">
                    <a href="tel:+919876543210" className="text-blue-600 hover:text-blue-800">
                      +91 98765 43210
                    </a>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="border border-gray-300 p-3 font-medium">Night Canteen</td>
                  <td className="border border-gray-300 p-3">9:00 PM - 2:00 AM</td>
                  <td className="border border-gray-300 p-3">Maggi, Sandwiches, Tea/Coffee</td>
                  <td className="border border-gray-300 p-3">
                    <a href="tel:+919876543211" className="text-blue-600 hover:text-blue-800">
                      +91 98765 43211
                    </a>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="border border-gray-300 p-3 font-medium">Juice Corner</td>
                  <td className="border border-gray-300 p-3">7:00 AM - 9:00 PM</td>
                  <td className="border border-gray-300 p-3">Fresh Juices, Smoothies</td>
                  <td className="border border-gray-300 p-3">
                    <a href="tel:+919876543212" className="text-blue-600 hover:text-blue-800">
                      +91 98765 43212
                    </a>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </CollapsibleSection>

        {/* Warden Contacts */}
        <CollapsibleSection 
          title="Warden Contact Info" 
          icon={<User size={24} />}
        >
          <div className="grid md:grid-cols-2 gap-4">
            <ContactCard name="Krishna Bhavan" phone="+91 98765 43213" label="Warden: Dr. Smith" />
            <ContactCard name="Budh Bhavan" phone="+91 98765 43214" label="Warden: Dr. Johnson" />
            <ContactCard name="Meera Bhavan" phone="+91 98765 43215" label="Warden: Dr. Patel" />
            <ContactCard name="Malviya Bhavan" phone="+91 98765 43216" label="Warden: Dr. Kumar" />
            <ContactCard name="Vyas Bhavan" phone="+91 98765 43217" label="Warden: Dr. Singh" />
            <ContactCard name="Ram Bhavan" phone="+91 98765 43218" label="Warden: Dr. Sharma" />
          </div>
        </CollapsibleSection>

        {/* 212 Bus Schedule */}
        <CollapsibleSection 
          title="🚌 212 Bus Schedule (BPHC ↔ Secunderabad)" 
          icon={<Bus size={24} />}
        >
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h3 className="font-semibold text-green-800 mb-3 flex items-center">
                <MapPin size={16} className="mr-2" />
                From BPHC
              </h3>
              <div className="space-y-2">
                {['9:00 AM', '10:00 AM', '2:00 PM', '5:00 PM', '6:00 PM'].map((time) => (
                  <div key={time} className="bg-white p-2 rounded text-center font-medium text-green-700">
                    {time}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h3 className="font-semibold text-blue-800 mb-3 flex items-center">
                <MapPin size={16} className="mr-2" />
                From Secunderabad
              </h3>
              <div className="space-y-2">
                {['7:50 AM', '8:50 AM', '12:45 PM', '4:00 PM', '5:00 PM'].map((time) => (
                  <div key={time} className="bg-white p-2 rounded text-center font-medium text-blue-700">
                    {time}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CollapsibleSection>

        {/* Alternate Bus Routes */}
        <CollapsibleSection 
          title="Alternate Bus Routes" 
          icon={<Bus size={24} />}
        >
          <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200 mb-4">
            <div className="flex items-center mb-2">
              <AlertTriangle size={20} className="text-yellow-600 mr-2" />
              <span className="font-semibold text-yellow-800">Important Note</span>
            </div>
            <p className="text-yellow-700 text-sm">
              Confirm with the conductor before boarding to ensure it stops at your destination.
            </p>
          </div>
          
          <div className="bg-white p-4 rounded-lg border border-gray-200">
            <h3 className="font-semibold text-gray-800 mb-3">
              From Secunderabad to Thumkunta/Tandoor Junction:
            </h3>
            <div className="flex flex-wrap gap-2">
              {['211A', '211B', '211C', '211DY', '212T', '212/564', '212/567', '212/568', '212/702', '564', '567', '568'].map((route) => (
                <span key={route} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                  {route}
                </span>
              ))}
            </div>
          </div>
        </CollapsibleSection>

        {/* Auto Rickshaw Drivers */}
        <CollapsibleSection 
          title="🚗 Auto Rickshaw Drivers Near Campus" 
          icon={<Car size={24} />}
        >
          <div className="bg-red-50 p-4 rounded-lg border border-red-200 mb-6">
            <div className="flex items-center mb-2">
              <AlertTriangle size={20} className="text-red-600 mr-2" />
              <span className="font-bold text-red-800">🚨 Fair Distribution Reminder</span>
            </div>
            <p className="text-red-700 font-medium">
              Please pick a random number. Don't just call the first person every time to distribute work fairly.
            </p>
          </div>
          
          <AutoDriverGrid />
        </CollapsibleSection>

        {/* Footer */}
        <div className="bg-gradient-to-r from-gray-100 to-gray-200 p-6 rounded-xl mt-8">
          <div className="flex items-center mb-3">
            <Users size={20} className="text-gray-600 mr-2" />
            <span className="font-semibold text-gray-700">Contributors</span>
          </div>
          <p className="text-gray-600 text-sm mb-3">
            Viswanath Reddy, Shreyas Reddy, Mohammed Abdul Rahman Khan, Harsha Sista, Rohit Dwivedula, Rushabh Musthyala.
          </p>
          <p className="text-gray-500 text-sm">
            To add or update info, drop a comment below.
          </p>
        </div>

      </div>
    </div>
  );
}

export default App;